MTB = 10

print(f'{MTB} mtb')