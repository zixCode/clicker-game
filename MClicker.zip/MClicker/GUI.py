import tkinter as tk

HEIGHT = 700
WIDTH = 800

click_count_string = 0
money = 100
bonus = 0
bonus_multiply = 1
Refresh = True


#                                           \REFRESH START/


def refresh_money_count():
    global Money_Count
    Money_Count = tk.Label(frame, text=f"{money}  money", fg="white", bg="black")
    Money_Count.place(relx=0.57, rely=0.02, relwidth=0.2, relheight=0.05)


def refresh_text_count():
    global Text_count
    Text_count = tk.Label(frame, text=f'{click_count_string}    clicks', fg='white', bg='black')
    Text_count.place(relx=0.8, rely=0.02, relwidth=0.2, relheight=0.05)


def refresh_logo():
    global logo
    global logo_img
    logo_img = tk.PhotoImage(file="coollogo_com-28006393.gif")
    logo = tk.Label(frame_up, image=logo_img)
    logo.place(relx=0, rely=0.1, relwidth=0.3, relheight=0.8)


#                                         \REFRESH END/
#                                       \BUTTONS AND SHOP/

def click_count_trigered():
    global click_count_string
    global Text_count
    click_count_string += 1
    refresh_text_count()
    refresh_logo()


def click_transform_clicks():
    global money
    global click_count_string
    global Money_Count
    global Text_count
    if click_count_string > 0:
        money = money + (click_count_string * (5 + bonus)) * bonus_multiply
    click_count_string = 0
    refresh_money_count()
    refresh_text_count()
    refresh_logo()


def restart():
    global click_count_string
    global money
    global bonus
    global bonus_multiply
    click_count_string = 0
    money = 0
    bonus = 0
    bonus_multiply = 1
    refresh_money_count()
    refresh_text_count()
    refresh_logo()


def shop_plus2():
    global bonus
    global money
    global Money_Count
    if money >= 500:
        bonus = bonus + 2
        money = money - 500
    refresh_money_count()
    refresh_logo()


def shop_or2():
    global bonus_multiply
    global money
    if money >= 5000:
        bonus_multiply = bonus_multiply + 1
        money = money - 5000
    refresh_money_count()
    refresh_logo()


def rebirth():
    global money
    global bonus
    global bonus_multiply
    global click_count_string

    if money >= 10000:
        money = money - 10000
        bonus = 5
        bonus_multiply = 1
        click_count_string = 0

    refresh_money_count()
    refresh_text_count()
    refresh_logo()


#                                          \BUTTONS AND SHOP/
#                                               \DRAW/

root = tk.Tk()

canvas = tk.Canvas(root, height=HEIGHT, width=WIDTH)
canvas.pack()


frame = tk.Frame(root, bg='#80c1ff')
frame.place(relwidth=1, relheight=1, rely=0, relx=0)


frame_up = tk.Frame(frame, bg="gray")
frame_up.place(relwidth=1, relheight=0.1, rely=0, relx=0)


frame_shop = tk.Frame(frame, bg="red")
frame_shop.place(relwidth=1, relheight=0.2, rely=0.1, relx=0)


logo_img = tk.PhotoImage(file="coollogo_com-28006393.gif")
logo = tk.Label(frame_up, image=logo_img)
logo.place(relx=0, rely=0.1, relwidth=0.3, relheight=0.8)


Shop_label = tk.Label(frame_shop, text=f"Shop", fg='Yellow', bg='red')
Shop_label.place(relwidth=1, relheight=0.2, rely=0, relx=0)


Text_count = tk.Label(frame, text=f'{click_count_string}    clicks', fg='white', bg='black')
Text_count.place(relx=0.8, rely=0.02, relwidth=0.2, relheight=0.05)


Money_Count = tk.Label(frame, text=f"{money}   money", fg="white", bg="black")
Money_Count.place(relx=0.57, rely=0.02, relwidth=0.2, relheight=0.05)


button_click = tk.Button(frame, text="Make clicks", fg="black", bg="gray", command=click_count_trigered)
button_click.place(relx=0.4, rely=0.5, relwidth=0.15, relheight=0.15)


button_transform_money = tk.Button(frame, text="Transform clicks into money", fg='black', bg='yellow',
                                   command=click_transform_clicks)
button_transform_money.place(relx=0.37, rely=0.7, relwidth=0.2, relheight=0.05)


button_restart = tk.Button(frame, text='Restart', fg="black", bg="#B40404", command=restart)
button_restart.place(relx=0.85, rely=0.93, relwidth=0.15, relheight=0.08)


#                                           \SHOP BUTTONS/

button_shop_plus2money = tk.Button(frame_shop, text="Plus 2 money / click, $500", fg="black", bg="yellow",
                                   command=shop_plus2)
button_shop_plus2money.place(relx=0.02, rely=0.1, relwidth=0.18, relheight=0.15)


button_shop_or2 = tk.Button(frame_shop, text='Or 2 Money, $5000', fg="black", bg="yellow", command=shop_or2)
button_shop_or2.place(relx=0.02, rely=0.3, relwidth=0.18, relheight=0.15)


button_shop_rebirth = tk.Button(frame_shop, text="Rebirth, $10000", fg="black", bg="yellow", command=rebirth)
button_shop_rebirth.place(relx=0.02, rely=0.5, relwidth=0.18, relheight=0.15)

#                                           \SHOP BUTTONS/

root.mainloop()

#                                             \DRAW END/
